#include "TutorialApplication.h"

#include <OgreException.h>
#include <OgreConfigFile.h>
#include <OgreRenderWindow.h>
#include <OgreCamera.h> 
#include <OgreViewport.h> 
#include <OgreSceneManager.h>
#include <OgreEntity.h>






TutorialApplication::TutorialApplication(void) : 
	mRoot(0),
	mCamera(0),
	mSceneMgr(0),
	mWindow(0),
	mCameraMan(0),
	mMouse(0),
	mKeyboard(0),
	mResourcesCfg(Ogre::StringUtil::BLANK),
	mPluginsCfg(Ogre::StringUtil::BLANK)
{

}


TutorialApplication::~TutorialApplication(void)
{
	if (mCameraMan) delete mCameraMan;

	Ogre::WindowEventUtilities::removeWindowEventListener(mWindow, this); 
	windowClosed(mWindow);
	delete mRoot;
}


bool TutorialApplication::configure(void)
{
	if(mRoot->showConfigDialog())
    {
        mWindow = mRoot->initialise(true, "TutorialApplication Render Window");
		return true;
    }
    
	else
    {
        return false;
    }
}

void TutorialApplication::chooseSceneManager(void)
{
    // Get the SceneManager, in this case a generic one
    mSceneMgr = mRoot->createSceneManager(Ogre::ST_GENERIC);

}

void TutorialApplication::createCamera(void)
{
	mCamera = mSceneMgr->createCamera("MainCam"); 

	mCamera->setPosition(0, 0, 80); 
	mCamera->lookAt(0, 0, -300);
	mCamera->setNearClipDistance(5);

	mCameraMan = new OgreBites::SdkCameraMan(mCamera);
}

void TutorialApplication::createFrameListener(void)
{
	Ogre::LogManager::getSingletonPtr()->logMessage("*** Initializing OIS ***"); 
	OIS::ParamList pl; 
	size_t windowHnd = 0; 
	std::ostringstream windowHndStr;
	
	mWindow->getCustomAttribute("WINDOW", &windowHnd);
	windowHndStr << windowHnd; 
	pl.insert(std::make_pair(std::string("WINDOW"), windowHndStr.str()));
	
	mInputMgr = OIS::InputManager::createInputSystem( pl );

	mKeyboard = static_cast<OIS::Keyboard*>(mInputMgr->createInputObject( OIS::OISKeyboard, true )); 
	mMouse = static_cast<OIS::Mouse*>(mInputMgr->createInputObject( OIS::OISMouse, true ));
	
	
	//mMouse->setEventCallback(this);
	//mKeyboard->setEventCallback(this);

	// Set initial mouse clipping size 
	windowResized(mWindow);
	
	// Register as a Window listener 
	Ogre::WindowEventUtilities::addWindowEventListener(mWindow, this);
	
	// Register as a Frame listener 
	mRoot->addFrameListener(this);
	

}

void TutorialApplication::createViewports(void)
{
	Ogre::Viewport* vp = mWindow->addViewport(mCamera); 
	vp->setBackgroundColour(Ogre::ColourValue(0, 0, 0));

	mCamera->setAspectRatio( Ogre::Real(vp->getActualWidth()) / Ogre::Real(vp->getActualHeight()));
}

void TutorialApplication::setupResources(void)
{
	Ogre::ConfigFile cf; 
	cf.load(mResourcesCfg);
	
	Ogre::String name, locType; 
	Ogre::ConfigFile::SectionIterator secIt = cf.getSectionIterator();

	while (secIt.hasMoreElements()) 
	{ 
		Ogre::ConfigFile::SettingsMultiMap* settings = secIt.getNext(); 
		Ogre::ConfigFile::SettingsMultiMap::iterator it;

		for (it = settings->begin(); it != settings->end(); ++it) 
		{ 
			locType = it->first; 
			name = it->second;
		    
			Ogre::ResourceGroupManager::getSingleton().addResourceLocation(name, locType);
		}
	}
}
void TutorialApplication::createResourceListener(void)
{

}

void TutorialApplication::loadResources(void)
{
	Ogre::ResourceGroupManager::getSingleton().initialiseAllResourceGroups();
}


void TutorialApplication::go() 
{ 
	#ifdef _DEBUG 
		mResourcesCfg = "resources_d.cfg"; 
		mPluginsCfg = "plugins_d.cfg"; 
	#else 
		mResourcesCfg = "resources.cfg"; 
		mPluginsCfg = "plugins.cfg"; 
	#endif	
		

	
	// The first parameter determines whether or not Ogre will create a RenderWindow for us. 
	

	if(!setup())
		return;
	
	mRoot->startRendering();

	destroyScene();
}

bool TutorialApplication::setup()
{
	mRoot = new Ogre::Root(mPluginsCfg);

	setupResources();

	bool carryOn = configure();
    if (!carryOn) return false;

	chooseSceneManager();
	createCamera();
	createViewports();

	Ogre::TextureManager::getSingleton().setDefaultNumMipmaps(5);

	loadResources();

	createScene();

	createFrameListener();

	return true;
}

bool TutorialApplication::frameRenderingQueued(const Ogre::FrameEvent& fe) 
{ 
	if (mWindow->isClosed()) 
		return false;
	
	if (mKeyboard->isKeyDown(OIS::KC_ESCAPE)) 
		return false;
		
	mKeyboard->capture(); 
	mMouse->capture();


	return true;
}

bool TutorialApplication::keyPressed(const OIS::KeyEvent& ke)
{

	return true;
}

bool TutorialApplication::keyReleased(const OIS::KeyEvent &ke)
{

    return true;
}

bool TutorialApplication::mouseMoved(const OIS::MouseEvent& me) 
{
	
    mCameraMan->injectMouseMove(me);
	return true;
}

bool TutorialApplication::mousePressed(const OIS::MouseEvent& me, OIS::MouseButtonID id)
{
	return true;
}

void TutorialApplication::createScene(void)
{
	Ogre::Entity* ogreEntity = mSceneMgr->createEntity("ogrehead.mesh");
	Ogre::SceneNode* ogreNode = mSceneMgr->getRootSceneNode()->createChildSceneNode(); 
	ogreNode->attachObject(ogreEntity);
	mSceneMgr->setAmbientLight(Ogre::ColourValue(.5, .5, .5));
	Ogre::Light* light = mSceneMgr->createLight("MainLight"); 
	light->setPosition(20, 80, 50);
}

void TutorialApplication::destroyScene(void)
{

}

void TutorialApplication::windowResized(Ogre::RenderWindow* rw) 
{ 
	int left, top; 
	unsigned int width, height, depth;
	rw->getMetrics(width, height, depth, left, top);

	const OIS::MouseState& ms = mMouse->getMouseState(); 
	ms.width = width; 
	ms.height = height;
}

void TutorialApplication::windowClosed(Ogre::RenderWindow* rw) 
{ 
	if(rw == mWindow) 
	{ 
		 if(mInputMgr) 
		 { 
			mInputMgr->destroyInputObject(mMouse); 
			mInputMgr->destroyInputObject(mKeyboard);
			
			OIS::InputManager::destroyInputSystem(mInputMgr); 
			mInputMgr = 0;
		 }
	}
}

#if OGRE_PLATFORM == OGRE_PLATFORM_WIN32 
#define WIN32_LEAN_AND_MEAN 
#include "windows.h" 
#endif

#ifdef __cplusplus 
extern "C" 
{ 
#endif

#if OGRE_PLATFORM == OGRE_PLATFORM_WIN32 
	INT WINAPI WinMain( HINSTANCE hInst, HINSTANCE, LPSTR strCmdLine, INT ) 
#else 
	int main(int argc, char *argv[]) 
#endif 
{ 
	TutorialApplication app;
  
	try 
	{
	 app.go();
	}

	catch(Ogre::Exception& e) 
	{ 
#if OGRE_PLATFORM == OGRE_PLATFORM_WIN32 
	MessageBox( 
		NULL, 
		e.getFullDescription().c_str(), 
		"An exception has occured!", 
		MB_OK | MB_ICONERROR | MB_TASKMODAL); 
#else 
		std::cerr << "An exception has occured: " << 
			e.getFullDescription().c_str() << std::endl; 
#endif 
		}
		
		return 0;
	} 
#ifdef __cplusplus 
} 
#endif