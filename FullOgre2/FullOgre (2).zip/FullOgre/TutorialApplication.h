#pragma once

#include <OgreRoot.h>
#include <OgreWindowEventUtilities.h>
#include <OISEvents.h> 
#include <OISInputManager.h> 
#include <OISKeyboard.h> 
#include <OISMouse.h>
#include <SdkCameraMan.h>



class TutorialApplication : public Ogre::WindowEventListener, public Ogre::FrameListener
{	
	
private: 
	Ogre::Root* mRoot; 
	Ogre::String mResourcesCfg; 
	Ogre::String mPluginsCfg;
	Ogre::RenderWindow* mWindow;
	Ogre::SceneManager* mSceneMgr; 
	Ogre::Camera* mCamera;

	OgreBites::SdkCameraMan*    mCameraMan;

	OIS::InputManager* mInputMgr; 
	OIS::Mouse* mMouse; 
	OIS::Keyboard* mKeyboard;

	
protected:
	virtual bool configure(void);
	virtual void chooseSceneManager(void);
	virtual void createCamera(void);
	virtual void createFrameListener(void);
	virtual void createViewports(void);
	virtual void setupResources(void);
	virtual void createResourceListener(void);
	virtual void loadResources(void);
	virtual bool setup();
	virtual bool frameRenderingQueued(const Ogre::FrameEvent& fe);
	virtual bool keyPressed(const OIS::KeyEvent& ke);
	virtual bool keyReleased(const OIS::KeyEvent& ke);
	virtual bool mouseMoved(const OIS::MouseEvent &arg);
	virtual bool mousePressed(const OIS::MouseEvent& me, OIS::MouseButtonID id); 
	virtual void createScene(void);
	virtual void destroyScene(void);
	virtual void windowResized(Ogre::RenderWindow* rw); 
	virtual void windowClosed(Ogre::RenderWindow* rw);
public:
	TutorialApplication(void);
	virtual ~TutorialApplication(void);
	virtual void go();

	
};

